<?php

namespace App\Components;

use App\Components\BaseComponent;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;


class HeaderComponent extends BaseComponent{
    private $profile_menu;
    private $logout_btn;
    private $project_tab; 
    private $mywork_tab;

    public function __construct($driver) {
        parent::__construct($driver);
       // Initialize locators here
        $this->profile_menu = WebDriverBy::className('navbar__user__avatar__link');
        $this->logout_btn = WebDriverBy::xpath("//div[normalize-space()='Log out']");
        $this->project_tab = WebDriverBy::xpath("//div[@class='navbar__menu']//span[normalize-space()='Projects']");
        $this->mywork_tab = WebDriverBy::xpath("//div[@class='navbar__menu']//span[normalize-space()='My work']");

    }


    public function switchToProjectsView() {
        $this->driver->findElement($this->project_tab)->click();
    }

    public function switchToMyWorkView() {
        $this->driver->findElement($this->mywork_tab)->click();
    }

    public function openProfileMenu() {
        $this->driver->findElement($this->profile_menu)->click();
    }

    public function logout() {
        $this->openProfileMenu();
        $logout_lnk = $this->wait->until(
            WebDriverExpectedCondition::visibilityOfElementLocated($this->logout_btn));
            $logout_lnk->click();
    }
    
}
