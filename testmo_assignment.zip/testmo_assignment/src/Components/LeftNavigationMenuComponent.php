<?php

namespace App\Components;

use App\Components\BaseComponent;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;


class LeftNavigationMenuComponent extends BaseComponent{
   
    public function __construct($driver) {
        parent::__construct($driver);
    }


    public function navigateToSideMenuItem($leftMenuItem) {
        $this->driver->findElement(WebDriverBy::xpath(sprintf("//span[normalize-space()='%s']", $leftMenuItem)))->click();
        sleep($this->config['sleep_time']);
    }

   
    
}

