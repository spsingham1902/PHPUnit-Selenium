<?php

namespace App\Components;

use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverWait;
Use Facebook\WebDriver\WebDriverExpectedCondition;

abstract class BaseComponent {
    protected $driver;

    public function __construct(RemoteWebDriver $driver) {
        $this->driver = $driver;
        // Load the configuration file
        $configPath = __DIR__ . '/../../config/test_config.json';
        $this->config = json_decode(file_get_contents($configPath), true);
        $this->wait = new WebDriverWait($this->driver, $this->config['wait_time']); 
    }
}
