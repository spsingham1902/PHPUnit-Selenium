<?php

namespace App\Pages;

use App\Pages\BasePage;
use App\Components\HeaderComponent;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverKeys;
use Facebook\WebDriver\WebDriverExpectedCondition;

class ProjectsDashboardPage extends BasePage {

    private $header;
    private $search_fld;
    private $project_name;

    public function __construct($driver) {
        parent::__construct($driver);
       // Initializing page locators and including header component
        $this->search_fld = WebDriverBy::xpath("//input[@placeholder='Search' and @type='text']");
        $this->header = new HeaderComponent($this->driver);

      }


    public function getHeader() {
        return $this->header;
    }

    public function searchProject($projectName) {
        $this->driver->findElement($this->search_fld)->sendKeys($projectName . WebDriverKeys::ENTER);
        sleep($this->config['sleep_time']);
    }

    public function openProject($projectName) {
      
       $this->searchProject($projectName);
      
       $this->project_name = WebDriverBy::xpath(sprintf(
           "//div[@data-name='activeProjects']//td[@class='table__field__avatar-text']//a[contains(text(), '%s')]",
             $projectName));
       
           $Project = $this->wait->until(
               WebDriverExpectedCondition::visibilityOfElementLocated($this->project_name));
           $Project->click();
           sleep($this->config['sleep_time']);
       
      
      }
}
