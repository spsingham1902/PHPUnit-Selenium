<?php

namespace App\Pages;

use Facebook\WebDriver\WebDriverWait;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;

class BasePage {
    protected $driver;
    protected $config;
    protected $wait;

    public function __construct($driver) {
        $this->driver = $driver;

        // Load the configuration file
        $configPath = __DIR__ . '/../../config/test_config.json';
        $this->config = json_decode(file_get_contents($configPath), true);
        $this->wait = new WebDriverWait($this->driver, $this->config['wait_time']); 
    }
}
