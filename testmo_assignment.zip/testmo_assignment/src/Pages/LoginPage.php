<?php

namespace App\Pages;

use App\Pages\BasePage;
use App\Components\HeaderComponent;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;



class LoginPage extends BasePage {
    private $email_input;
    private $password_input; 
    private $remember_chkbox;
    private $login_btn;
    Private $forgotPassword_lnk;
    
    public function __construct($driver) {
        parent::__construct($driver);
       // Initializing page locators 
        $this->email_input = WebDriverBy::xpath("//input[@name='email' and @type='text']");
        $this->password_input = WebDriverBy::xpath("//input[@name='password' and @type='password']");
        $this->remember_chkbox = WebDriverBy::xpath("//input[@name='remember' and @type='checkbox']");
        $this->login_btn = WebDriverBy::xpath("//button[@type='submit']");
        $this->forgotPassword_lnk= WebDriverBy::linkText("Forgot password");
    }

    public function navigateToLogin() {
        $this->driver->get($this->config['base_url'] . '/auth/login');
    }
    public function login($username, $password) {
        $email_fld = $this->wait->until(
            WebDriverExpectedCondition::visibilityOfElementLocated($this->email_input));
            
        $email_fld->sendKeys($username);
        $this->driver->findElement($this->password_input)->sendKeys($password);
        $this->driver->findElement($this->login_btn)->click();
    }
}
