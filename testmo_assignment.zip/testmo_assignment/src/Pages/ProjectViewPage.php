<?php

namespace App\Pages;

use App\Pages\BasePage;
use App\Components\HeaderComponent;
use App\Components\LeftNavigationMenuComponent;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverKeys;
use Facebook\WebDriver\WebDriverExpectedCondition;


class ProjectViewPage extends BasePage {

    private $header;
    private $leftNavigationMenu;
  

    public function __construct($driver) {
        parent::__construct($driver);
       // Initializing page locators and including header component
        $this->header = new HeaderComponent($this->driver);
        $this->leftNavigationMenu= new LeftNavigationMenuComponent($this->driver);

      }


    public function getLeftNavigation() {
        return $this->leftNavigationMenu;
    }

   
}
