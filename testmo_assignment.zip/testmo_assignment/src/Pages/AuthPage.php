<?php

namespace App\Pages;

use App\Pages\BasePage;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;


class AuthPage extends BasePage {
    private $LoginWithTestMo_btn ;

    public function __construct($driver) {
        parent::__construct($driver);
       // Initializing page locators 
        $this->LoginWithTestMo_btn = WebDriverBy::xpath("//a[contains(., 'Log in with') and contains(., 'Testmo')]");
       
    }

    public function navigateToAuthPage() {
        $this->driver->get($this->config['base_url'] . '/auth');
    }
    
    public function openLoginWithTestMoPage() {
        // Wait until the 'Log in with TestMo' button is visible
        $login_btn = $this->wait->until(
            WebDriverExpectedCondition::visibilityOfElementLocated($this->LoginWithTestMo_btn)
        );
        // Click the 'Log in with Testmo' button
        $login_btn->click();
        // Pause execution for 2 seconds
        sleep($this->config['sleep_time']); 
    }
}
