<?php

namespace App\Pages;

use App\Pages\BasePage;
use App\Components\HeaderComponent;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;

class JobsPage extends BasePage {

    private $header;
    private $search_fld;
    private $addAutomationJob_btn;
    private $automationJobQueue_grid;

    // Add Job Dialog elements
    private $addJobDialog_target_dd;
    private $addJobDialog_previewSettings_fld;
    private $addJobDialog_addJob_btn;
    private $addJobDialog_cancel_btn;




    public function __construct($driver) {
        
        parent::__construct($driver);
        // Initializing page and Job Dilaog locators and including header component
        $this->addAutomationJob_btn = WebDriverBy::xpath("//button[@data-target='automation--jobs--index.addButton']");
        $this->automationJobQueue_grid = WebDriverBy::className("automation-jobs-queue__content");

        $this->addJobDialog_target_dd = WebDriverBy::xpath("//div[@class='dialog-container dialog-container--visible']/div[@class='dialog-container__inner']/div[@class='dialog dialog--compact']/div[@class='dialog__border']/div[@class='dialog__main']/div[@class='dialog__main__content']/div[@class='dialog__main__content__inner']/div[@class='ui form']/div[@class='field-section']/div[@class='field-section__fields']/div[@class='field required']/div[1]/div[1]");
        $this->addJobDialog_previewSettings_fld = WebDriverBy::xpath("//div[@class='dialog--compact']//div[@class='automation-jobs-add-settings']");
        $this->addJobDialog_addJob_btn = WebDriverBy::xpath("//button[@class='ui button primary']");
        $this->addJobDialog_cancel_btn = WebDriverBy::xpath("//button[@class='ui button dialog-hide']");


        $this->header = new HeaderComponent($this->driver);
      }

    public function getHeader() {
        return $this->header;
    }

    public function getAutomationJobQueueContent() {
        return $this->driver->findElement($this->automationJobQueue_grid).getText();
    }

    public function clickAddAutomationJobButton() {
         $this->driver->findElement($this->addAutomationJob_btn)->click();
         sleep($this->config['sleep_time']);

    }

    public function addTargetJob($jobItem) {
        $targetDD = $this->wait->until(
            WebDriverExpectedCondition::visibilityOfElementLocated($this->addJobDialog_target_dd)
        );    
        $targetDD->click();        
        $jobName = WebDriverBy::xpath("//div[@class='dropdown__items__row dropdown__items__row--item']//div[contains(@class,'dropdown__item')][normalize-space()='$jobItem']");
        $item = $this->wait->until(
            WebDriverExpectedCondition::visibilityOfElementLocated($jobName)
        );
        $item->click();
    }


    public function addAutomationJob($job) {
        $this->clickAddAutomationJobButton();
        $this->addTargetJob($job);
        $this->driver->findElement($this->addJobDialog_addJob_btn)->click();
        sleep($this->config['sleep_time']);

   }


   public function getAddedJobDetails($columnName) {
    try {
        // Locate the grid element
        $gridElement = $this->driver->findElement($this->automationJobQueue_grid);

        // Map column names to column numbers
        $columnMap = [
            "Queued job" => 1,
            "Connection" => 2,
            "Queued" => 3,
        ];

        // Check if column name exists in the map
        if (!isset($columnMap[$columnName])) {
            throw new \InvalidArgumentException("Invalid column name: $columnName");
        }

        $columnNumber = $columnMap[$columnName];

        // Build the XPath for the specific column
        $columnXPath = ".//table//tbody//tr[2]/td[$columnNumber]";

        // Find the child element relative to the grid element
        $columnElement = $gridElement->findElement(WebDriverBy::xpath($columnXPath));

        // Return the text of the found element
        return $columnElement->getText();
    } catch (\InvalidArgumentException $e) {
        // Handle invalid column name
        throw $e;
    } catch (\Exception $e) {
        // Handle general exceptions, such as element not found
        throw new \RuntimeException("Failed to retrieve details for column: $columnName", 0, $e);
    }
}


    
}
