<?php

use Qameta\Allure\Setup\LinkTemplateInterface;


return [
    'outputDirectory' => 'build/allure-results',
    'lifecycleHooks' => [],
    'setupHook' => null,

    'linkTemplates' => [

        'issue' =>
            new class implements LinkTemplateInterface {
                public function buildUrl(?string $name): ?string
                {
                    return "https://issues.example.com/$name";
                }
            },

        'tms' =>
            new class implements LinkTemplateInterface {
                public function buildUrl(?string $name): ?string
                {
                    return "https://tms.example.com/$name";
                }
            },

        'jira' =>
            new class implements LinkTemplateInterface {
                public function buildUrl(?string $name): ?string
                {
                    return "https://jira.example.com/browse/$name";
                }
            },
    ],
];

