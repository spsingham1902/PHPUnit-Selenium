
# Test Automation Framework Setup

This document outlines the steps for setting up and executing the Test Automation Framework based on PHPUnit, Selenium WebDriver, and Allure for reporting.

## Prerequisites

1. **PHP**: Ensure PHP 8.0 or higher is installed on your system.
2. **Composer**: Composer is required to manage dependencies. Install it from [here](https://getcomposer.org/download/).
3. **Selenium WebDriver**: Make sure you have Selenium WebDriver running (locally or using a remote server).
4. **FFmpeg**: Required for video recording during test execution. Install FFmpeg from [here](https://ffmpeg.org/download.html).
5. **Google Chrome**: Ensure Google Chrome is installed for running tests with Chrome WebDriver.

## Setting Up the Project

### 1. unzip the folder

### 2. Install Dependencies

Run the following command to install the required dependencies using Composer:

```bash
composer install
```

### 3. WebDriver Setup

Ensure that Selenium WebDriver is running. 
```bash
java -jar selenium-server-standalone-<version>.jar
```
or 
```bash
./chromedriver
```

Make sure that the WebDriver is running at the address defined in your `test_config.json` file.

### 4. Update Configuration File

Update `config/test_config.json` with the following information:

- **`webdriver_port`**: Port where the Selenium WebDriver is running.
- **`base_url`**: The base URL of the application under test.
- **`credentials`**: Add your login credentials (username and password) for TestMo or any other system you're using for login.

Example `test_config.json`:

```json
 "base_url": "https://sjpknight.testmo.net",
    "credentials": {
        "username": "shailendraAutomationQa@gmail.com",
        "password": "Qwerty123#"
    },
   "webdriver_port": "60370",
   "wait_time": 10,
   "sleep_time": 2,
   "project_name": "Candidate SS Test",
   "GitHub_Job": "GitHub (GitHub)",
   "GitLab_Job": "GitLab (sjpknight Gitlab)"


```

### 5. FFmpeg Setup

Ensure FFmpeg is installed for video recording during test execution. You can verify if it's working by running the following command:

```bash
ffmpeg -version
```

If it's not installed, download it from [here](https://ffmpeg.org/download.html).

## Running Tests

### 1. Run PHPUnit Tests

Run the tests using PHPUnit. This will execute all tests under the `tests/Functional` directory.

```bash
./vendor/bin/phpunit --configuration phpunit.xml
```

### 2. Run Specific Test Case

To run a specific test case, use the following command:

```bash
./vendor/bin/phpunit --filter <TestCaseName> --configuration phpunit.xml
```

For example, to run tests in the `JobsTest` class:

```bash
./vendor/bin/phpunit --filter JobsTest --configuration phpunit.xml
```

### 3. Allure Reports

After running the tests, Allure reports will be generated automatically. To view the reports, run the following command:

```bash
allure serve <path-to-allure-results>
```

Replace `<path-to-allure-results>` with the actual path where Allure results are saved (by default, it should be `tests/_output/allure-results`).

### 4. Video Recording

Video recordings of the tests are captured using FFmpeg. The videos will be saved in the `logs/videos/` directory.

- If a test fails, the corresponding video will be attached to the Allure report.

