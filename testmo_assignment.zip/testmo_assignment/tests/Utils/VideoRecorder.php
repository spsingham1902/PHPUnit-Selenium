<?php

namespace Tests\Utils;

class VideoRecorder
{
    private $process;
    private $outputFile;

    public function start(string $testName): void
    {
        $videoPath = __DIR__ . '/../../logs/videos/';
        if (!file_exists($videoPath)) {
            mkdir($videoPath, 0777, true);
        }
        $this->outputFile = "$videoPath/{$testName}.mp4";

        $command = sprintf(
            'ffmpeg -y -video_size 1920x1080 -framerate 25 -f avfoundation -i "1:0" "%s" > /dev/null 2>&1 & echo $!',
            $this->outputFile
        );
        

        $descriptors = [
            0 => ["pipe", "r"], // STDIN
            1 => ["pipe", "w"], // STDOUT
            2 => ["pipe", "w"], // STDERR
        ];

        $this->process = proc_open($command, $descriptors, $pipes);

        if (is_resource($this->process)) {
            // Log FFmpeg output for debugging
            file_put_contents($videoPath . 'ffmpeg.log', stream_get_contents($pipes[1]));
            fclose($pipes[1]);
        }
    }

    public function stop(): void
    {
        if ($this->process) {
            proc_terminate($this->process);
            proc_close($this->process);
        }
    }

    public function getOutputFile(): string
    {
        return $this->outputFile;
    }
}
