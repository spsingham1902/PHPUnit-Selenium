<?php
namespace Tests\Utils;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class TestLogger
{
    private $logger;

    public function __construct($logFile = __DIR__ . '/../../logs/testmo_tests.log')
    {
        $this->logger = new Logger('test_logger');
        $this->logger->pushHandler(new StreamHandler($logFile, Logger::DEBUG));
        $this->logger->pushHandler(new StreamHandler('php://stdout', Logger::INFO));

    }

    // Log a message at INFO level
    public function logInfo($message)
    {
        $this->logger->info($message);
    }

    // Log a message at ERROR level
    public function logError($message)
    {
        $this->logger->error($message);
    }

    // Log a message at DEBUG level
    public function logDebug($message)
    {
        $this->logger->debug($message);
    }
}

