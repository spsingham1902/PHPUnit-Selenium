<?php

namespace Tests\Functional;

use Tests\Hooks\TestHooks;
use PHPUnit\Framework\TestCase;
use App\Pages\LoginPage;
use App\Pages\AuthPage;
use App\Pages\ProjectsDashboardPage;
use App\Pages\ProjectViewPage;
use App\Pages\JobsPage;

use Qameta\Allure\Attribute\Description;
use Qameta\Allure\Attribute\Label;
use Qameta\Allure\Attribute\Severity;
use Qameta\Allure\Attribute\Owner;
use Qameta\Allure\Attribute\Issue;
use Qameta\Allure\Attribute\Link;
use Qameta\Allure\Attribute\TmsLink;
use Qameta\Allure\Attribute\AllureId;


class JobsTest extends BaseTest {
   public function setUp(): void {
    parent::setUp(); 
    // On Project Dashboard , search and open Project
     $projectsDashboardPage = new ProjectsDashboardPage(self::$driver);
     $projectsDashboardPage->openProject(self::$config['project_name']);
     self::$logger->logInfo('Open Project: '.self::$config['project_name']);

           
     //Navigate to Projects Jobs page 
      $projectViewPage = new ProjectViewPage(self::$driver);
      $projectViewPage->getLeftNavigation()->navigateToSideMenuItem("Jobs");
      self::$logger->logInfo('Navigated to Jobs View of selected project');

}

    #[Description('This is to verify add automation Job functionality')]
    #[Label('testId', 'TID-0001')]
    #[Severity('critical')]
    #[Owner('Shailendra')]
    #[Link('My Website', 'https://example.com/')]
    #[Issue('UI-001')]
    #[TmsLink('Tmo-001')]
    #[AllureId('tc-123')]
    public function testAddAutomationJobFunctionality() {
        // Add Automation Job
        $jobsPage = new JobsPage(self::$driver);
        $jobsPage->addAutomationJob(self::$config['GitHub_Job']);
        self::$logger->logInfo('Added new job:'.self::$config['GitHub_Job']);


        // Verify Automation Job Added successfully 
        $this->assertStringContainsString($jobsPage->getAddedJobDetails("Queued job"), "GitHub", "'Queued Job' does not match");
        $this->assertStringContainsString($jobsPage->getAddedJobDetails("Connection"), "GitHub", "'Connection' does not match");
        $this->assertStringContainsString('Just now', $jobsPage->getAddedJobDetails("Queued"), "'Queued' does not match");
        self::$logger->logInfo('Job added successfully');


    }

}