<?php

namespace Tests\Functional;

use App\Pages\LoginPage;
use App\Components\HeaderComponent;
use App\Pages\AuthPage;
use Tests\Utils\TestLogger;
use PHPUnit\Framework\TestCase;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Qameta\Allure\Allure;
use Tests\Utils\VideoRecorder;



abstract class BaseTest extends TestCase {
    protected static $driver;
    protected static $config;
    protected static $logger;
    private $videoRecorder;
    

    public static function setUpBeforeClass(): void {       
        self::$logger = new TestLogger();
        self::$logger->logInfo('Test cases started.');

       // Load the configuration file
       $configPath = __DIR__ . '/../../config/test_config.json';
       self::$config = json_decode(file_get_contents($configPath), true);
       $serverUrl = 'http://localhost:'.self::$config['webdriver_port'];
       $capabilities = DesiredCapabilities::chrome();
       self::$driver = RemoteWebDriver::create($serverUrl, $capabilities);

       self::$logger->logInfo('Selenium WebDriver initialized.');

    }

    public function setUp(): void {
        $testName = $this->getName();
        $this->videoRecorder = new VideoRecorder();
        $this->videoRecorder->start($testName);

        $authPage = new AuthPage(self::$driver);
        // Naviagate to testmo auth page
        $authPage->navigateToAuthPage();
        self::$logger->logInfo('Navigating to Auth Page');

        // Click Login with TestMo button and open login page
        $authPage->openLoginWithTestMoPage();
        // Verify login page open
        $currentUrl = self::$driver->getCurrentURL();
        $this->assertStringContainsString(self::$config['base_url'] . '/auth/login', $currentUrl, "Does not navidate to testmo login page");
        self::$logger->logInfo('TestMo Login Page open');

        // Login applicaiton
        $loginPage = new LoginPage(self::$driver);
        //$loginPage->navigateToLogin();
        $loginPage->login(self::$config['credentials']['username'], self::$config['credentials']['password']);
        self::$logger->logInfo('User Log in TestMo');

    }
   
    protected function onNotSuccessfulTest(\Throwable $t): void {
         // Check the type of the failure or error
        $errorMessage = $t->getMessage();
        $errorClass = get_class($t);

        // Log or handle the error
        self::$logger->logError("Test failed: " . $errorMessage);

        if (self::$driver) {
            // Capture screenshot on failure
            $screenshotPath = __DIR__ . '/../../logs/screenshots/';
            if (!file_exists($screenshotPath)) {
                mkdir($screenshotPath, 0777, true);
            }
            $screenshotFile = $screenshotPath . 'failure_' . time() . '.png';
            self::$driver->takeScreenshot($screenshotFile);
            $this->attachScreenshotToAllure($screenshotFile);
            self::$logger->logError("Test failed. Screenshot captured: $screenshotFile");
        }
        parent::onNotSuccessfulTest($t);
    }

    private function attachScreenshotToAllure(string $filePath): void {
        if (file_exists($filePath)) {
            Allure::attachmentFile('FailedAttachFile', $filePath, 'image/png');
        }
    }

    public function tearDown(): void {

        $this->videoRecorder->stop();

        $videoPath = $this->videoRecorder->getOutputFile();

        if (!$this->hasFailed()) {
            $header = new HeaderComponent(self::$driver);
            // Logout from the application only if the test did not fail
            $header->logout();
            self::$logger->logInfo('User logged out of TestMo');
            
            if (file_exists($videoPath)) {
                unlink($videoPath,);
            } else {
                self::$logger->logError("Video file does not exist.");
            }

        } else {
            $videoPath = $this->videoRecorder->getOutputFile();
            if (file_exists($videoPath)) {
                Allure::attachmentFile('Test Video', $videoPath, 'video/mp4');
            } else {
                self::$logger->logError("Video file does not exist.");
            }

            self::$logger->logInfo('Test failed. Skipping logout to preserve browser state.');
        }
    }

    public static function tearDownAfterClass(): void {
        if (self::$driver) {
            self::$driver->quit();
        }
        self::$logger->logInfo('Selenium WebDriver session ended.');
        
     
}
    
}

